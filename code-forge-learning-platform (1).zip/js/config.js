/**
 * ============================================
 * CODE FORGE - Configuration & Constants
 * ============================================
 * 
 * IMPORTANT: This file contains configuration placeholders.
 * DO NOT put real API keys in frontend code.
 * All sensitive values should be loaded from environment variables
 * via a secure backend API endpoint.
 */

const CONFIG = {
    // ==========================================
    // API Keys (PLACEHOLDERS - Load from backend)
    // ==========================================
    
    /**
     * OpenAI API Configuration
     * Required for ChatGPT integration
     * 
     * HOW TO CONFIGURE:
     * 1. Get API key from https://platform.openai.com/api-keys
     * 2. Set as environment variable on your backend: OPENAI_API_KEY
     * 3. Backend should expose this through a secure API endpoint, never to frontend directly
     */
    OPENAI: {
        API_KEY: '', // Placeholder - will be fetched from backend
        MODEL: 'gpt-4o-mini', // or 'gpt-4o', 'gpt-3.5-turbo'
        ENDPOINT: '/api/ai/chatgpt', // Your backend endpoint
        MAX_TOKENS: 4096,
        TEMPERATURE: 0.7,
        AVAILABLE: true, // Whether this provider is available
        REQUIRE_AUTH: false, // Guest users can use this
        REQUIRE_VIP: false,
        CONFIGURED: false // Set to true when backend is ready
    },

    /**
     * Google Gemini API Configuration
     * Requires Google OAuth authentication
     * 
     * HOW TO CONFIGURE:
     * 1. Create project at https://aistudio.google.com/
     * 2. Enable Gemini API
     * 3. Set up Google OAuth 2.0 credentials
     * 4. Configure GEMINI_API_KEY on your backend
     */
    GEMINI: {
        API_KEY: '', // Placeholder - will be fetched from backend
        MODEL: 'gemini-1.5-flash',
        ENDPOINT: '/api/ai/gemini',
        MAX_TOKENS: 8192,
        TEMPERATURE: 0.7,
        AVAILABLE: true,
        REQUIRE_AUTH: true, // Requires Google sign-in
        REQUIRE_VIP: false,
        CONFIGURED: false
    },

    /**
     * Anthropic Claude API Configuration
     * Requires active VIP subscription
     * 
     * HOW TO CONFIGURE:
     * 1. Get API key from https://console.anthropic.com/
     * 2. Set ANTHROPIC_API_KEY on your backend
     * 3. Ensure VIP subscription verification is implemented
     */
    CLAUDE: {
        API_KEY: '', // Placeholder - will be fetched from backend
        MODEL: 'claude-3-5-sonnet-20241022',
        ENDPOINT: '/api/ai/claude',
        MAX_TOKENS: 8192,
        TEMPERATURE: 0.7,
        AVAILABLE: true,
        REQUIRE_AUTH: true,
        REQUIRE_VIP: true, // Only VIP users can access
        CONFIGURED: false
    },

    // ==========================================
    // Authentication Configuration
    // ==========================================
    
    AUTH: {
        // Google OAuth 2.0 Configuration
        GOOGLE: {
            CLIENT_ID: '', // Your Google OAuth Client ID
            REDIRECT_URI: window.location.origin + '/auth/google/callback',
            SCOPE: 'email profile openid',
            ENDPOINT: '/auth/google',
            CONFIGURED: false
        },
        
        // Session storage key
        SESSION_KEY: 'codeforge_session',
        
        // Token refresh interval (in milliseconds)
        TOKEN_REFRESH_INTERVAL: 30 * 60 * 1000, // 30 minutes
        
        // Session duration (in milliseconds)
        SESSION_DURATION: 24 * 60 * 60 * 1000 // 24 hours
    },

    // ==========================================
    // Payment/Subscription Configuration
    // ==========================================
    
    PAYMENT: {
        // Payment gateway (options: 'razorpay', 'stripe', 'paypal')
        PROVIDER: 'razorpay',
        
        RAZORPAY: {
            KEY_ID: '', // Your Razorpay Key ID
            KEY_SECRET: '', // NEVER expose this to frontend
            ENDPOINT: '/api/payment/razorpay',
            CURRENCY: 'INR',
            VIP_AMOUNT: 10000, // Amount in paise (₹100 = 10000 paise)
            CONFIGURED: false
        },
        
        STRIPE: {
            PUBLISHABLE_KEY: '', // Stripe publishable key (safe for frontend)
            ENDPOINT: '/api/payment/stripe',
            PRICE_ID: '', // Your VIP price ID
            CONFIGURED: false
        },
        
        // Subscription plan details
        VIP_PLAN: {
            ID: 'vip_monthly',
            NAME: 'VIP Plan',
            PRICE: 100, // ₹100
            CURRENCY: 'INR',
            BILLING_PERIOD: 'monthly',
            FEATURES: [
                'Full access to Claude AI assistant',
                'Access to Gemini AI (with Google auth)',
                'All 50+ projects unlocked',
                'Premium project templates',
                'Advanced playground features',
                'Ad-free experience',
                'Priority support'
            ]
        }
    },

    // ==========================================
    // Application Settings
    // ==========================================
    
    APP: {
        NAME: 'Code Forge',
        VERSION: '1.0.0',
        DESCRIPTION: 'Learn, Code, Build & Create with AI',
        
        // Theme settings
        DEFAULT_THEME: 'dark',
        THEME_STORAGE_KEY: 'codeforge_theme',
        
        // User preferences storage key
        PREFS_STORAGE_KEY: 'codeforge_prefs',
        
        // Learning progress storage key
        PROGRESS_STORAGE_KEY: 'codeforge_progress',
        
        // Projects storage key
        PROJECTS_STORAGE_KEY: 'codeforge_projects',
        
        // Max chat history messages to keep
        MAX_CHAT_HISTORY: 50,
        
        // Playground settings
        PLAYGROUND: {
            AUTO_RUN_DELAY: 500, // ms before auto-run after typing stops
            MAX_OUTPUT_SIZE: 100000, // Max output characters
            SUPPORTED_LANGUAGES: ['html-css-js', 'javascript']
        }
    },

    // ==========================================
    // API Endpoints (Backend)
    // ==========================================
    
    API: {
        BASE_URL: '', // Your API base URL (e.g., 'https://api.codeforge.dev')
        
        // Authentication endpoints
        AUTH: {
            LOGIN: '/auth/login',
            SIGNUP: '/auth/signup',
            LOGOUT: '/auth/logout',
            REFRESH: '/auth/refresh',
            GOOGLE: '/auth/google',
            ME: '/auth/me'
        },
        
        // User endpoints
        USER: {
            PROFILE: '/user/profile',
            PREFERENCES: '/user/preferences',
            DASHBOARD: '/user/dashboard'
        },
        
        // Learning endpoints
        LEARNING: {
            COURSES: '/learning/courses',
            LESSONS: '/learning/lessons',
            PROGRESS: '/learning/progress'
        },
        
        // Projects endpoints
        PROJECTS: {
            LIST: '/projects',
            GET: '/projects/:id',
            SAVE: '/projects/save',
            DELETE: '/projects/delete'
        },
        
        // Subscription endpoints
        SUBSCRIPTION: {
            STATUS: '/subscription/status',
            CREATE: '/subscription/create',
            CANCEL: '/subscription/cancel'
        }
    },

    // ==========================================
    // Error Messages
    // ==========================================
    
    ERRORS: {
        // Auth errors
        INVALID_CREDENTIALS: 'Invalid email or password',
        EMAIL_REQUIRED: 'Email address is required',
        PASSWORD_REQUIRED: 'Password is required',
        PASSWORD_MIN_LENGTH: 'Password must be at least 6 characters',
        PASSWORDS_DONT_MATCH: 'Passwords do not match',
        NAME_REQUIRED: 'Name is required',
        
        // AI errors
        AI_NOT_CONFIGURED: 'AI provider is not configured. Please contact administrator.',
        AI_RATE_LIMITED: 'Too many requests. Please try again later.',
        AI_NETWORK_ERROR: 'Network error. Please check your connection.',
        AI_RESPONSE_ERROR: 'Error processing response. Please try again.',
        
        // Provider-specific errors
        GEMINI_REQUIRES_AUTH: 'Gemini requires Google authentication. Please sign in with Google.',
        CLAUDE_REQUIRES_VIP: 'Claude is exclusive to VIP members. Upgrade to VIP to access.',
        
        // General errors
        NETWORK_ERROR: 'Unable to connect to server. Please check your internet connection.',
        UNKNOWN_ERROR: 'An unexpected error occurred. Please try again.',
        
        // Project errors
        PROJECT_SAVE_FAILED: 'Failed to save project. Please try again.',
        PROJECT_LOAD_FAILED: 'Failed to load project.'
    },

    // ==========================================
    // Success Messages
    // ==========================================
    
    SUCCESS: {
        LOGIN_SUCCESS: 'Welcome back!',
        LOGOUT_SUCCESS: 'You have been logged out successfully.',
        PROFILE_UPDATED: 'Profile updated successfully!',
        PASSWORD_UPDATED: 'Password updated successfully!',
        PROJECT_SAVED: 'Project saved successfully!',
        CODE_COPIED: 'Code copied to clipboard!'
    }
};

// Export for module usage (if using modules)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
}