/**
 * ============================================
 * CODE FORGE - Authentication Manager
 * ============================================
 */

const AuthManager = {
    // Current user state
    user: null,
    
    // Initialize
    init() {
        this.loadSession();
        this.bindEvents();
        this.updateUI();
    },
    
    // Load session from storage
    loadSession() {
        try {
            const sessionData = localStorage.getItem(CONFIG.AUTH.SESSION_KEY);
            if (sessionData) {
                const session = JSON.parse(sessionData);
                if (session && session.token) {
                    this.user = session;
                    // Check token expiry (simplified)
                    if (session.expiresAt && Date.now() > session.expiresAt) {
                        this.logout();
                        return;
                    }
                }
            }
        } catch (e) {
            console.warn('Error loading session:', e);
            this.clearSession();
        }
    },
    
    // Save session to storage
    saveSession(userData) {
        const session = {
            ...userData,
            expiresAt: Date.now() + CONFIG.AUTH.SESSION_DURATION
        };
        this.user = session;
        localStorage.setItem(CONFIG.AUTH.SESSION_KEY, JSON.stringify(session));
    },
    
    // Clear session
    clearSession() {
        this.user = null;
        localStorage.removeItem(CONFIG.AUTH.SESSION_KEY);
    },
    
    // Check if user is logged in
    isLoggedIn() {
        return this.user !== null && !!this.user.token;
    },
    
    // Check if user is VIP
    isVIP() {
        return this.isLoggedIn() && 
               this.user.subscription === 'vip' && 
               this.user.vipActive === true;
    },
    
    // Check if user is Google authenticated
    isGoogleAuthenticated() {
        return this.isLoggedIn() && 
               this.user.provider === 'google';
    },
    
    // Get user display name
    getDisplayName() {
        if (!this.isLoggedIn()) return 'Guest';
        return this.user.name || 'User';
    },
    
    // Login with email/password
    async login(email, password) {
        try {
            showLoading();
            
            // In production, this would call your backend API:
            // const response = await fetch(CONFIG.API.AUTH.LOGIN, { ... });
            
            // Demo mode - simulate login (remove in production)
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Validate inputs
            if (!email || !password) {
                throw new Error('Please fill in all fields');
            }
            
            // Simulate successful login
            const mockUser = {
                id: 'user_' + Date.now(),
                name: email.split('@')[0],
                email: email,
                avatar: null,
                token: 'demo_token_' + Date.now(),
                provider: 'email',
                subscription: 'free',
                vipActive: false,
                createdAt: new Date().toISOString()
            };
            
            this.saveSession(mockUser);
            this.updateUI();
            
            showToast('success', 'Login Successful', `Welcome back, ${mockUser.name}!`);
            navigateTo('dashboard');
            hideLoading();
            
            return true;
        } catch (error) {
            hideLoading();
            showToast('error', 'Login Failed', error.message || CONFIG.ERRORS.INVALID_CREDENTIALS);
            return false;
        }
    },
    
    // Signup
    async signup(name, email, password) {
        try {
            showLoading();
            
            // In production: call backend API
            
            // Demo mode - validate and create account
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            if (!name || !email || !password) {
                throw new Error('Please fill in all fields');
            }
            
            if (password.length < 6) {
                throw new Error(CONFIG.ERRORS.PASSWORD_MIN_LENGTH);
            }
            
            const mockUser = {
                id: 'user_' + Date.now(),
                name: name,
                email: email,
                avatar: null,
                token: 'demo_token_' + Date.now(),
                provider: 'email',
                subscription: 'free',
                vipActive: false,
                createdAt: new Date().toISOString()
            };
            
            this.saveSession(mockUser);
            this.updateUI();
            
            showToast('success', 'Account Created', `Welcome to Code Forge, ${name}!`);
            navigateTo('dashboard');
            hideLoading();
            
            return true;
        } catch (error) {
            hideLoading();
            showToast('error', 'Signup Failed', error.message);
            return false;
        }
    },
    
    // Google Sign-In
    async googleSignIn() {
        try {
            showLoading();
            
            // In production, use actual Google OAuth flow:
            // 1. Initialize Google Sign-In SDK
            // 2. Show Google popup
            // 3. Handle callback
            // 4. Send ID token to backend for verification
            // 5. Receive user data from backend
            
            // Demo mode - simulate Google auth
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            const mockGoogleUser = {
                id: 'google_user_' + Date.now(),
                name: 'Google User',
                email: 'user@gmail.com',
                avatar: null,
                token: 'google_token_' + Date.now(),
                provider: 'google',
                subscription: 'free',
                vipActive: false,
                createdAt: new Date().toISOString()
            };
            
            this.saveSession(mockGoogleUser);
            this.updateUI();
            
            showToast('success', 'Google Sign-In Success', 'You are now authenticated!');
            hideLoading();
            
            return true;
        } catch (error) {
            hideLoading();
            showToast('error', 'Authentication Failed', error.message);
            return false;
        }
    },
    
    // Logout
    logout() {
        this.clearSession();
        this.updateUI();
        
        // Navigate to home
        if (typeof navigateTo === 'function') {
            navigateTo('home');
        }
        
        showToast('success', 'Logged Out', CONFIG.SUCCESS.LOGOUT_SUCCESS);
    },
    
    // Update UI based on auth state
    updateUI() {
        const accountName = document.getElementById('account-name');
        const dropdownUsername = document.getElementById('dropdown-username');
        const dropdownStatus = document.getElementById('dropdown-status');
        const dashboardMenu = document.getElementById('menu-dashboard');
        const loginMenuBtn = document.getElementById('login-menu-btn');
        const logoutMenuBtn = document.getElementById('logout-menu-btn');
        const dashUsername = document.getElementById('dash-username');
        
        if (this.isLoggedIn()) {
            const displayName = this.getDisplayName();
            
            if (accountName) accountName.textContent = displayName;
            if (dropdownUsername) dropdownUsername.textContent = displayName;
            if (dropdownStatus) {
                if (this.isVIP()) {
                    dropdownStatus.textContent = 'VIP Member';
                    dropdownStatus.style.color = '#f59e0b';
                } else if (this.isGoogleAuthenticated()) {
                    dropdownStatus.textContent = 'Google Account';
                } else {
                    dropdownStatus.textContent = 'Logged in';
                }
            }
            if (dashboardMenu) dashboardMenu.style.display = 'flex';
            if (loginMenuBtn) loginMenuBtn.style.display = 'none';
            if (logoutMenuBtn) logoutMenuBtn.style.display = 'flex';
            if (dashUsername) dashUsername.textContent = displayName;
        } else {
            if (accountName) accountName.textContent = 'Guest';
            if (dropdownUsername) dropdownUsername.textContent = 'Guest User';
            if (dropdownStatus) {
                dropdownStatus.textContent = 'Not logged in';
                dropdownStatus.style.color = '';
            }
            if (dashboardMenu) dashboardMenu.style.display = 'none';
            if (loginMenuBtn) loginMenuBtn.style.display = 'flex';
            if (logoutMenuBtn) logoutMenuBtn.style.display = 'none';
        }
        
        // Update AI provider access indicators
        this.updateProviderAccess();
        
        // Update VIP status displays
        this.updateVIPDisplays();
    },
    
    // Update AI provider access states
    updateProviderAccess() {
        const geminiStatus = document.querySelector('#provider-gemini .provider-status');
        const claudeStatus = document.querySelector('#provider-claude .provider-status');
        
        if (geminiStatus) {
            if (this.isGoogleAuthenticated()) {
                geminiStatus.className = 'provider-status available';
                geminiStatus.textContent = 'Available';
            } else if (this.isLoggedIn()) {
                geminiStatus.className = 'provider-status needs-auth';
                geminiStatus.textContent = 'Auth Required';
            } else {
                geminiStatus.className = 'provider-status needs-auth';
                geminiStatus.textContent = 'Auth Required';
            }
        }
        
        if (claudeStatus) {
            if (this.isVIP()) {
                claudeStatus.className = 'provider-status available';
                claudeStatus.textContent = 'Available';
            } else if (this.isLoggedIn() && !this.isVIP()) {
                claudeStatus.className = 'provider-status vip-only';
                claudeStatus.textContent = 'Upgrade Required';
            } else {
                claudeStatus.className = 'provider-status vip-only';
                claudeStatus.textContent = 'VIP Only';
            }
        }
    },
    
    // Update VIP-related displays
    updateVIPDisplays() {
        const planBadge = document.getElementById('dash-plan-badge');
        const accountBadge = document.getElementById('account-status-badge');
        const currentPlanName = document.getElementById('current-plan-name');
        const subPlanName = document.getElementById('sub-plan-name');
        const subActions = document.getElementById('sub-actions');
        
        if (this.isVIP()) {
            if (planBadge) {
                planBadge.innerHTML = '<i class="fas fa-crown"></i> VIP Member';
                planBadge.classList.add('vip');
            }
            if (accountBadge) {
                accountBadge.textContent = 'VIP Member';
                accountBadge.classList.add('vip');
            }
            if (currentPlanName) currentPlanName.textContent = 'VIP Plan (₹100/month)';
            if (subPlanName) subPlanName.textContent = 'VIP Plan';
            if (subActions) subActions.innerHTML = '<button class="btn btn-outline" disabled>Active Subscription</button>';
        } else {
            if (planBadge) {
                planBadge.innerHTML = '<i class="fas fa-user"></i> Free Plan';
                planBadge.classList.remove('vip');
            }
            if (accountBadge) {
                accountBadge.textContent = this.isLoggedIn() ? 'Free User' : 'Guest';
                accountBadge.classList.remove('vip');
            }
            if (currentPlanName) currentPlanName.textContent = 'Free Plan';
            if (subPlanName) subPlanName.textContent = 'Free Plan';
            if (subActions) subActions.innerHTML = '<button class="btn btn-vip" data-page="vip">Upgrade to VIP</button>';
        }
    },
    
    // Bind event listeners
    bindEvents() {
        // Logout button
        document.querySelectorAll('#logout-menu-btn').forEach(btn => {
            btn.addEventListener('click', () => this.logout());
        });
        
        // Login menu button
        document.getElementById('login-menu-btn')?.addEventListener('click', () => {
            closeAllDropdowns();
            navigateTo('auth');
        });
        
        // Login form
        document.getElementById('login-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = document.getElementById('login-email')?.value;
            const password = document.getElementById('login-password')?.value;
            this.login(email, password);
        });
        
        // Signup form
        document.getElementById('signup-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('signup-name')?.value;
            const email = document.getElementById('signup-email')?.value;
            const password = document.getElementById('signup-password')?.value;
            this.signup(name, email, password);
        });
        
        // Form tabs
        document.querySelectorAll('.form-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                const formType = tab.dataset.form;
                
                // Update tab active state
                document.querySelectorAll('.form-tab').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                
                // Update form visibility
                document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
                document.getElementById(`${formType}-form`)?.classList.add('active');
            });
        });
        
        // Password toggle buttons
        document.querySelectorAll('.toggle-password').forEach(btn => {
            btn.addEventListener('click', () => {
                const targetId = btn.dataset.target;
                const input = document.getElementById(targetId);
                const icon = btn.querySelector('i');
                
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.replace('fa-eye', 'fa-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.replace('fa-eye-slash', 'fa-eye');
                }
            });
        });
        
        // Google sign-in buttons
        document.getElementById('google-signin-btn')?.addEventListener('click', () => {
            this.googleSignIn();
        });
        
        document.getElementById('google-signup-btn')?.addEventListener('click', () => {
            this.googleSignIn();
        });
        
        // Delete account button
        document.getElementById('delete-account-btn')?.addEventListener('click', () => {
            if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
                this.logout();
                showToast('info', 'Account Deleted', 'Your account has been deleted.');
            }
        });
        
        // Save profile
        document.getElementById('profile-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('profile-name')?.value;
            if (name && this.user) {
                this.user.name = name;
                this.saveSession(this.user);
                this.updateUI();
                showToast('success', 'Profile Updated', CONFIG.SUCCESS.PROFILE_UPDATED);
            }
        });
    },
    
    // Check if can use specific AI provider
    canUseProvider(providerId) {
        switch(providerId) {
            case 'chatgpt':
                return CONFIG.OPENAI.CONFIGURED; // Available if configured
            case 'gemini':
                return this.isGoogleAuthenticated(); // Requires Google auth
            case 'claude':
                return this.isVIP(); // Requires VIP subscription
            default:
                return false;
        }
    }
};

// Helper functions for loading state
function showLoading() {
    const overlay = document.getElementById('loading-overlay');
    if (overlay) overlay.style.display = 'flex';
}

function hideLoading() {
    const overlay = document.getElementById('loading-overlay');
    if (overlay) overlay.style.display = 'none';
}

// Toast notification function
function showToast(type, title, message) {
    const container = document.getElementById('toast-container');
    if (!container) return;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <i class="fas ${icons[type]} toast-icon"></i>
        <div class="toast-content">
            <div class="toast-title">${title}</div>
            <div class="toast-message">${message}</div>
        </div>
        <button class="toast-close" onclick="this.parentElement.classList.add('toast-exit'); setTimeout(() => this.parentElement.remove(), 300)">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    container.appendChild(toast);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (toast.parentElement) {
            toast.classList.add('toast-exit');
            setTimeout(() => toast.remove(), 300);
        }
    }, 5000);
}

// Close all dropdowns
function closeAllDropdowns() {
    document.getElementById('account-dropdown')?.querySelector('.dropdown-menu')?.classList.remove('show');
}

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', () => {
    AuthManager.init();
});