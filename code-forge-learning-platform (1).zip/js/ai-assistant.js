/**
 * ============================================
 * CODE FORGE - AI Assistant Manager
 * ============================================
 */

const AIAssistantManager = {
    currentProvider: 'chatgpt',
    chatHistory: [],
    isGenerating: false,
    
    // Initialize
    init() {
        this.renderWelcomeMessage();
        this.bindEvents();
        AuthManager.updateProviderAccess();
    },
    
    // Render initial welcome message
    renderWelcomeMessage() {
        const messagesContainer = document.getElementById('chat-messages');
        if (!messagesContainer) return;
        
        // Keep welcome message if it's there, or restore it
        if (this.chatHistory.length === 0) {
            messagesContainer.innerHTML = `
                <div class="welcome-message">
                    <div class="welcome-icon"><i class="fas fa-robot"></i></div>
                    <h3>Welcome to Code Forge AI</h3>
                    <p>I'm here to help you with coding tasks. Ask me anything about:</p>
                    <ul>
                        <li>Writing or explaining code</li>
                        <li>Debugging and fixing errors</li>
                        <li>Building projects step by step</li>
                        <li>Learning programming concepts</li>
                        <li>Best practices and patterns</li>
                    </ul>
                    <p>Try one of the quick actions or type your question below!</p>
                </div>
            `;
        }
    },
    
    // Check access to a provider
    checkProviderAccess(providerId) {
        switch (providerId) {
            case 'chatgpt':
                if (!CONFIG.OPENAI.CONFIGURED) {
                    this.showConfigError('ChatGPT', 'OPENAI_API_KEY is not configured on the server.');
                    return false;
                }
                return true;
                
            case 'gemini':
                if (!AuthManager.isGoogleAuthenticated()) {
                    this.showAuthRequiredModal('gemini');
                    return false;
                }
                if (!CONFIG.GEMINI.CONFIGURED) {
                    this.showConfigError('Gemini', 'GEMINI_API_KEY is not configured on the server.');
                    return false;
                }
                return true;
                
            case 'claude':
                if (!AuthManager.isVIP()) {
                    this.showVIPUpgradeModal('claude');
                    return false;
                }
                if (!CONFIG.CLAUDE.CONFIGURED) {
                    this.showConfigError('Claude', 'ANTHROPIC_API_KEY is not configured on the server.');
                    return false;
                }
                return true;
                
            default:
                return false;
        }
    },
    
    // Show config error message
    showConfigError(providerName, missingKey) {
        const errorMsg = `
            <strong>${providerName} Not Configured</strong><br><br>
            The ${providerName} integration requires server configuration.
            Missing: ${missingKey}<br><br>
            Please contact the administrator to set up ${providerName}.
        `;
        
        this.addMessage(errorMsg, 'ai', true);
    },
    
    // Show auth required modal for Gemini
    showAuthRequiredModal(provider) {
        const modal = document.getElementById('google-auth-modal');
        modal.style.display = 'flex';
        
        // Bind confirm button
        document.getElementById('confirm-google-auth').onclick = () => {
            modal.style.display = 'none';
            AuthManager.googleSignIn().then(() => {
                // Try to use provider again after auth
                if (provider === 'gemini') {
                    this.selectProvider('gemini');
                }
            });
        };
        
        // Bind cancel button
        document.getElementById('cancel-google-auth').onclick = () => {
            modal.style.display = 'none';
        };
        
        document.getElementById('close-google-modal').onclick = () => {
            modal.style.display = 'none';
        };
    },
    
    // Show VIP upgrade modal for Claude
    showVIPUpgradeModal(provider) {
        const modal = document.getElementById('vip-modal');
        modal.style.display = 'flex';
        
        // Bind buttons
        document.getElementById('confirm-upgrade').onclick = () => {
            modal.style.display = 'none';
            navigateTo('vip');
        };
        
        document.getElementById('cancel-upgrade').onclick = () => {
            modal.style.display = 'none';
        };
        
        document.getElementById('close-vip-modal').onclick = () => {
            modal.style.display = 'none';
        };
    },
    
    // Select provider
    selectProvider(providerId) {
        if (!this.checkProviderAccess(providerId)) {
            return;
        }
        
        this.currentProvider = providerId;
        
        // Update UI
        document.querySelectorAll('.provider-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.provider === providerId);
        });
        
        // Update chat header display
        const displayEl = document.getElementById('chat-provider-display');
        const providerNames = {
            chatgpt: { name: 'ChatGPT', icon: 'fa-comment-dots' },
            gemini: { name: 'Gemini', icon: 'fa-brain' },
            claude: { name: 'Claude', icon: 'fa-shield-halved' }
        };
        
        if (displayEl && providerNames[providerId]) {
            displayEl.innerHTML = `<i class="fas ${providerNames[providerId].icon}"></i> 
                                    <span>${providerNames[providerId].name}</span>`;
        }
    },
    
    // Send message
    async sendMessage() {
        const input = document.getElementById('chat-input');
        const sendBtn = document.getElementById('send-btn');
        const message = input?.value.trim();
        
        if (!message || this.isGenerating) return;
        
        // Clear input
        input.value = '';
        input.style.height = 'auto';
        sendBtn.disabled = true;
        
        // Add user message
        this.addMessage(message, 'user');
        this.hideWelcomeMessage();
        
        // Start generating response
        this.isGenerating = true;
        this.showTypingIndicator();
        
        try {
            await this.generateResponse(message);
        } catch (error) {
            console.error('AI Error:', error);
            this.addMessage(`Sorry, an error occurred: ${error.message || 'Unknown error'}`, 'ai', true);
        } finally {
            this.removeTypingIndicator();
            this.isGenerating = false;
            sendBtn.disabled = !input.value.trim();
        }
    },
    
    // Generate AI response
    async generateResponse(userMessage) {
        // In production, this would call your backend API:
        // const response = await fetch(CONFIG.API.BASE_URL + endpoint, {
        //     method: 'POST',
        //     headers: { ... },
        //     body: JSON.stringify({
        //         provider: this.currentProvider,
        //         messages: [...this.getApiMessages(), userMessage]
        //     })
        // });
        
        // For demo mode - simulate AI responses
        await new Promise(resolve => setTimeout(resolve, 1500 + Math.random() * 1500));
        
        const response = this.generateDemoResponse(userMessage);
        this.addMessage(response, 'ai');
        
        // Keep history limited
        if (this.chatHistory.length > CONFIG.APP.MAX_CHAT_HISTORY) {
            this.chatHistory = this.chatHistory.slice(-20);
        }
    },
    
    // Generate demo/simulated responses for development
    generateDemoResponse(message) {
        const lowerMsg = message.toLowerCase();
        
        // Context-aware demo responses
        if (lowerMsg.includes('hello') || lowerMsg.includes('hi')) {
            return `Hello! 👋 I'm Code Forge AI. How can I help you today? I can assist with:\n\n• **Writing code** in any programming language\n• **Debugging** issues in your code\n• **Explaining** concepts clearly\n• **Building projects** from scratch\n\nWhat would you like to work on?`;
        }
        
        if (lowerMsg.includes('portfolio') || lowerMsg.includes('website')) {
            return `I'd love to help you build a portfolio website! 🎨\n\nHere's what I recommend:\n\n\`\`\`html\n<!DOCTYPE html>\n<html>\n<head>\n    <title>My Portfolio</title>\n    <style>\n        body {\n            font-family: system-ui;\n            max-width: 800px;\n            margin: 0 auto;\n            padding: 2rem;\n        }\n        .hero {\n            text-align: center;\n            padding: 3rem 1rem;\n            background: linear-gradient(135deg, #667eea, #764ba2);\n            color: white;\n            border-radius: 12px;\n        }\n    </style>\n</head>\n<body>\n    <header class="hero">\n        <h1>Your Name</h1>\n        <p>A passionate developer</p>\n    </header>\n</body>\n</html>\n\`\`\`\n\nThis creates a modern, responsive portfolio foundation. Would you like me to add more sections like About, Projects, or Contact?`;
        }
        
        if (lowerMsg.includes('calculator') || lowerMsg.includes('calc')) {
            return `Here's how to build a calculator! 🧮\n\n\`\`\`javascript\nclass Calculator {\n    constructor() {\n        this.currentValue = '0';\n        this.previousValue = '';\n        this.operator = null;\n    }\n    \n    appendNumber(num) {\n        if (this.currentValue === '0') {\n            this.currentValue = num.toString();\n        } else {\n            this.currentValue += num.toString();\n        }\n    }\n    \n    setOperator(op) {\n        this.previousValue = this.currentValue;\n        this.operator = op;\n        this.currentValue = '0';\n    }\n    \n    calculate() {\n        const prev = parseFloat(this.previousValue);\n        const curr = parseFloat(this.currentValue);\n        \n        switch(this.operator) {\n            case '+': return prev + curr;\n            case '-': return prev - curr;\n            case '*': return prev * curr;\n            case '/': return curr !== 0 ? prev / curr : 'Error';\n        }\n    }\n}\n\`\`\`\n\nThis is a clean class-based implementation. You can now create HTML buttons that call these methods!\n\nWould you like me to also provide the HTML/CSS for the calculator UI?`;
        }
        
        if (lowerMsg.includes('explain') || lowerMsg.includes('what is')) {
            return `I'd be happy to explain! Let me break it down for you.\n\nCould you share the specific code or concept you'd like me to explain?\n\nIn the meantime, I can help with:\n• **Variables & Data Types**\n• **Functions & Scope**\n• **DOM Manipulation**\n• **Async Programming**\n• **Design Patterns**\n\nJust paste the code or describe the concept, and I'll give you a clear explanation with examples!`;
        }
        
        if (lowerMsg.includes('debug') || lowerMsg.includes('error') || lowerMsg.includes('fix')) {
            return `I can help debug your code! 🔍\n\nTo help me find the issue faster, please include:\n\n1. **The error message** you're seeing\n2. **The relevant code** causing the error\n3. **What you expected** vs **what's happening**\n\nCommon debugging steps I can walk you through:\n- Console.log at key points\n- Check variable types\n- Verify API responses\n- Look for typos\n- Check async timing issues\n\nShare your code and I'll help identify and fix the problem!`;
        }
        
        if (lowerMsg.includes('project idea') || lowerMsg.includes('build')) {
            return `Great question! Here are some project ideas based on skill level:\n\n### Beginner Projects 🌱\n- **To-Do List App** - Learn DOM manipulation & state management\n- **Weather Dashboard** - Practice API integration\n- **Unit Converter** - Build calculators with multiple modes\n\n### Intermediate Projects 🚀\n- **E-commerce Product Page** - Complex UI & interactions\n- **Task Manager with Categories** - CRUD operations & filtering\n- **Recipe Search App** - External APIs & data handling\n\n### Advanced Projects ⚡\n- **Real-time Chat Application** - WebSockets & databases\n- **Code Editor** - Syntax highlighting & auto-complete\n- **Portfolio CMS** - User authentication & admin panel\n\nWhich one interests you? I can guide you through building any of these!`;
        }
        
        // Default helpful response
        return `Thanks for your message! I'm currently running in **demo mode**, so my responses are simulated.\n\nIn production with real AI configuration, using **${this.currentProvider.toUpperCase()}**, I would be able to:\n\n✅ Write and explain complex code\n✅ Debug issues in your programs\n✅ Help design system architecture\n✅ Suggest best practices\n✅ Convert between programming languages\n\n### To enable full AI capabilities:\n\n1. Set up backend API server\n2. Configure API keys:\n   - \`OPENAI_API_KEY\` for ChatGPT\n   - \`GEMINI_API_KEY\` for Gemini (requires Google auth)\n   - \`ANTHROPIC_API_KEY\` for Claude (requires VIP)\n\nIs there something specific about coding I can help you understand?`;
    },
    
    // Get messages in API format
    getApiMessages() {
        return this.chatHistory.map(m => ({
            role: m.role,
            content: m.content
        }));
    },
    
    // Add message to chat
    addMessage(content, role, isError = false) {
        const container = document.getElementById('chat-messages');
        if (!container) return;
        
        // Store in history
        this.chatHistory.push({ role: role === 'user' ? 'user' : 'assistant', content });
        
        // Remove welcome message if present
        const welcomeMsg = container.querySelector('.welcome-message');
        if (welcomeMsg) welcomeMsg.remove();
        
        // Create message element
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${role}-message${isError ? ' error-message' : ''}`;
        
        const avatarIcon = role === 'user' ? 'fa-user' : 'fa-robot';
        
        messageDiv.innerHTML = `
            <div class="message-avatar">
                <i class="fas ${avatarIcon}"></i>
            </div>
            <div class="message-content">
                <div class="message-bubble">${this.formatMessage(content)}</div>
            </div>
        `;
        
        container.appendChild(messageDiv);
        
        // Scroll to bottom
        container.scrollTop = container.scrollHeight;
    },
    
    // Format message content (handle markdown-like syntax)
    formatMessage(content) {
        // Escape HTML first
        let formatted = content
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
        
        // Format code blocks
        formatted = formatted.replace(/```(\w*)\n([\s\S]*?)```/g, (match, lang, code) => {
            const copyBtn = `<button class="copy-btn" onclick="this.parentElement.querySelector('pre').select(); document.execCommand('copy'); this.textContent='Copied!';">
                <i class="fas fa-copy"></i> Copy
            </button>`;
            return `<div class="pre-container">${copyBtn}<pre><code class="language-${lang || 'text'}">${code.trim()}</code></pre></div>`;
        });
        
        // Format inline code
        formatted = formatted.replace(/`([^`]+)`/g, '<code>$1</code>');
        
        // Format bold
        formatted = formatted.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
        
        // Format italic
        formatted = formatted.replace(/\*([^*]+)\*/g, '<em>$1</em>');
        
        // Format line breaks
        formatted = formatted.replace(/\n/g, '<br>');
        
        return formatted;
    },
    
    // Hide welcome message
    hideWelcomeMessage() {
        const welcome = document.querySelector('#chat-messages .welcome-message');
        if (welcome) {
            welcome.style.display = 'none';
        }
    },
    
    // Show typing indicator
    showTypingIndicator() {
        const container = document.getElementById('chat-messages');
        if (!container) return;
        
        const typingDiv = document.createElement('div');
        typingDiv.className = 'message ai-message';
        typingDiv.id = 'typing-indicator';
        typingDiv.innerHTML = `
            <div class="message-avatar"><i class="fas fa-robot"></i></div>
            <div class="message-content">
                <div class="message-bubble">
                    <div class="typing-indicator">
                        <span></span><span></span><span></span>
                    </div>
                </div>
            </div>
        `;
        
        container.appendChild(typingDiv);
        container.scrollTop = container.scrollHeight;
    },
    
    // Remove typing indicator
    removeTypingIndicator() {
        document.getElementById('typing-indicator')?.remove();
    },
    
    // Clear conversation
    clearConversation() {
        this.chatHistory = [];
        
        const container = document.getElementById('chat-messages');
        if (container) {
            container.innerHTML = '';
            this.renderWelcomeMessage();
        }
        
        showToast('info', 'Cleared', 'Conversation has been cleared');
    },
    
    // Bind event listeners
    bindEvents() {
        // Provider selection
        document.querySelectorAll('.provider-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.selectProvider(btn.dataset.provider);
            });
        });
        
        // Send button
        document.getElementById('send-btn')?.addEventListener('click', () => {
            this.sendMessage();
        });
        
        // Input field
        const chatInput = document.getElementById('chat-input');
        if (chatInput) {
            // Enable/disable send button based on content
            chatInput.addEventListener('input', () => {
                document.getElementById('send-btn').disabled = !chatInput.value.trim();
            });
            
            // Handle Enter to send
            chatInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
            
            // Auto-resize textarea
            chatInput.addEventListener('input', function() {
                this.style.height = 'auto';
                this.style.height = Math.min(this.scrollHeight, 150) + 'px';
            });
        }
        
        // Quick action buttons
        document.querySelectorAll('.quick-action-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const prompt = btn.dataset.prompt;
                const input = document.getElementById('chat-input');
                if (input) {
                    input.value = prompt;
                    document.getElementById('send-btn').disabled = false;
                    input.focus();
                }
            });
        });
        
        // Clear conversation button
        document.getElementById('clear-chat-btn')?.addEventListener('click', () => {
            if (this.chatHistory.length > 0) {
                if (confirm('Clear all messages from this conversation?')) {
                    this.clearConversation();
                }
            }
        });
    }
};

// Expose globally
window.AIAssistantManager = AIAssistantManager;

document.addEventListener('DOMContentLoaded', () => {
    AIAssistantManager.init();
});