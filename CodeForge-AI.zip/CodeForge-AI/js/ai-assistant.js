/**
 * ============================================
 * CODE FORGE - Direct AI Assistant Manager
 * Supporting: ChatGPT, Gemini, and Claude
 * ============================================
 */

const AIAssistantManager = {
    currentProvider: 'chatgpt',
    chatHistory: [],
    isGenerating: false,
    
    // ⚠️ PASTE YOUR API KEYS DIRECTLY BETWEEN THE QUOTES BELOW ON YOUR PHONE
    OPENAI_API_KEY: "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",
    GEMINI_API_KEY: "AQ.Ab8RN6J1SJzZSYcUTXlWnLwv6PXFM4lZawTmQF34CMaEKOQsyw",
    CLAUDE_API_KEY: "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",
    
    init() {
        this.renderWelcomeMessage();
        this.bindEvents();
        
        // Unlocks all provider buttons in your UI instantly
        if (typeof AuthManager !== 'undefined') {
            AuthManager.isGoogleAuthenticated = () => true;
            AuthManager.isVIP = () => true;
            AuthManager.updateProviderAccess();
        }
    },
    
    renderWelcomeMessage() {
        const messagesContainer = document.getElementById('chat-messages');
        if (!messagesContainer) return;
        if (this.chatHistory.length === 0) {
            messagesContainer.innerHTML = `
                <div class="welcome-message">
                    <div class="welcome-icon"><i class="fas fa-robot"></i></div>
                    <h3>Welcome to Code Forge AI (Live Multi-Model Mode)</h3>
                    <p>I am connected directly to live AI engines! Switch between ChatGPT, Gemini, or Claude in the sidebar.</p>
                </div>
            `;
        }
    },
    
    checkProviderAccess(providerId) {
        return true; // Bypasses template error blocks
    },
    
    selectProvider(providerId) {
        this.currentProvider = providerId;
        document.querySelectorAll('.provider-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.provider === providerId);
        });
        const displayEl = document.getElementById('chat-provider-display');
        const providerNames = {
            chatgpt: { name: 'ChatGPT', icon: 'fa-comment-dots' },
            gemini: { name: 'Gemini', icon: 'fa-brain' },
            claude: { name: 'Claude', icon: 'fa-shield-halved' }
        };
        if (displayEl && providerNames[providerId]) {
            displayEl.innerHTML = `<i class="fas ${providerNames[providerId].icon}"></i> <span>${providerNames[providerId].name}</span>`;
        }
    },
    
    async sendMessage() {
        const input = document.getElementById('chat-input');
        const sendBtn = document.getElementById('send-btn');
        const message = input?.value.trim();
        
        if (!message || this.isGenerating) return;
        
        input.value = '';
        input.style.height = 'auto';
        sendBtn.disabled = true;
        
        this.addMessage(message, 'user');
        this.hideWelcomeMessage();
        
        this.isGenerating = true;
        this.showTypingIndicator();
        
        try {
            await this.generateResponse(message);
        } catch (error) {
            console.error('AI Error:', error);
            this.addMessage(`API Error: ${error.message || 'Check your keys, funding balance, or internet connection.'}`, 'ai', true);
        } finally {
            this.removeTypingIndicator();
            this.isGenerating = false;
            sendBtn.disabled = !input.value.trim();
        }
    },
    
    async generateResponse(userMessage) {
        let replyText = "";

        if (this.currentProvider === 'claude') {
            // 🚀 CLAUDE LIVE API CALL
            const response = await fetch('https://anthropic.com', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'x-api-key': this.CLAUDE_API_KEY,
                    'anthropic-version': '2023-06-01',
                    'dangerouslyAllowBrowser': 'true' // Tells Anthropic engine to allow direct browser call
                },
                body: JSON.stringify({
                    model: 'claude-3-5-sonnet-20241022',
                    max_tokens: 1520,
                    messages: [{ role: 'user', content: userMessage }]
                })
            });
            const data = await response.json();
            if (data.error) throw new Error(data.error.message);
            replyText = data.content[0].text;

        } else if (this.currentProvider === 'gemini') {
            // 🚀 GEMINI LIVE API CALL
            const response = await fetch(`https://googleapis.com{this.GEMINI_API_KEY}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: userMessage }] }]
                })
            });
            const data = await response.json();
            if (data.error) throw new Error(data.error.message);
            replyText = data.candidates[0].content.parts[0].text;

        } else {
            // 🚀 CHATGPT LIVE API CALL (Default Fallback)
            const response = await fetch('https://openai.com', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.OPENAI_API_KEY}`
                },
                body: JSON.stringify({
                    model: 'gpt-4o-mini',
                    messages: [{ role: 'user', content: userMessage }]
                })
            });
            const data = await response.json();
            if (data.error) throw new Error(data.error.message);
            replyText = data.choices[0].message.content;
        }
        
        this.addMessage(replyText, 'ai');
        
        if (this.chatHistory.length > 50) {
            this.chatHistory = this.chatHistory.slice(-20);
        }
    },
    
    addMessage(content, role, isError = false) {
        const container = document.getElementById('chat-messages');
        if (!container) return;
        
        this.chatHistory.push({ role: role === 'user' ? 'user' : 'assistant', content });
        
        const welcomeMsg = container.querySelector('.welcome-message');
        if (welcomeMsg) welcomeMsg.remove();
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${role}-message${isError ? ' error-message' : ''}`;
        const avatarIcon = role === 'user' ? 'fa-user' : 'fa-robot';
        
        messageDiv.innerHTML = `
            <div class="message-avatar"><i class="fas ${avatarIcon}"></i></div>
            <div class="message-content">
                <div class="message-bubble">${this.formatMessage(content)}</div>
            </div>
        `;
        
        container.appendChild(messageDiv);
        container.scrollTop = container.scrollHeight;
    },
    
    formatMessage(content) {
        let formatted = content.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        formatted = formatted.replace(/```(\w*)\n([\s\S]*?)```/g, (match, lang, code) => {
            return `<div class="pre-container"><pre><code class="language-${lang || 'text'}">${code.trim()}</code></pre></div>`;
        });
        formatted = formatted.replace(/`([^`]+)`/g, '<code>$1</code>');
        formatted = formatted.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
        return formatted.replace(/\n/g, '<br>');
    },
    
    hideWelcomeMessage() {
        const welcome = document.querySelector('#chat-messages .welcome-message');
        if (welcome) welcome.style.display = 'none';
    },
    
    showTypingIndicator() {
        const container = document.getElementById('chat-messages');
        if (!container) return;
        const typingDiv = document.createElement('div');
        typingDiv.className = 'message ai-message';
        typingDiv.id = 'typing-indicator';
        typingDiv.innerHTML = `
            <div class="message-avatar"><i class="fas fa-robot"></i></div>
            <div class="message-content">
                <div class="message-bubble"><div class="typing-indicator"><span></span><span></span><span></span></div></div>
            </div>
        `;
        container.appendChild(typingDiv);
        container.scrollTop = container.scrollHeight;
    },
    
    removeTypingIndicator() {
        document.getElementById('typing-indicator')?.remove();
    },
    
    clearConversation() {
        this.chatHistory = [];
        const container = document.getElementById('chat-messages');
        if (container) {
            container.innerHTML = '';
            this.renderWelcomeMessage();
        }
    },
    
    bindEvents() {
        document.querySelectorAll('.provider-btn').forEach(btn => {
            btn.addEventListener('click', () => this.selectProvider(btn.dataset.provider));
        });
        document.getElementById('send-btn')?.addEventListener('click', () => this.sendMessage());
        
        const chatInput = document.getElementById('chat-input');
        if (chatInput) {
            chatInput.addEventListener('input', () => {
                document.getElementById('send-btn').disabled = !chatInput.value.trim();
            });
            chatInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
        }
        document.getElementById('clear-chat-btn')?.addEventListener('click', () => this.clearConversation());
    }
};

document.addEventListener('DOMContentLoaded', () => {
    AIAssistantManager.init();
});
       this.currentValue = num.toString();\n        } else {\n            this.currentValue += num.toString();\n        }\n    }\n    \n    setOperator(op) {\n        this.previousValue = this.currentValue;\n        this.operator = op;\n        this.currentValue = '0';\n    }\n    \n    calculate() {\n        const prev = parseFloat(this.previousValue);\n        const curr = parseFloat(this.currentValue);\n        \n        switch(this.operator) {\n            case '+': return prev + curr;\n            case '-': return prev - curr;\n            case '*': return prev * curr;\n            case '/': return curr !== 0 ? prev / curr : 'Error';\n        }\n    }\n}\n\`\`\`\n\nThis is a clean class-based implementation. You can now create HTML buttons that call these methods!\n\nWould you like me to also provide the HTML/CSS for the calculator UI?`;
        }
        
        if (lowerMsg.includes('explain') || lowerMsg.includes('what is')) {
            return `I'd be happy to explain! Let me break it down for you.\n\nCould you share the specific code or concept you'd like me to explain?\n\nIn the meantime, I can help with:\n• **Variables & Data Types**\n• **Functions & Scope**\n• **DOM Manipulation**\n• **Async Programming**\n• **Design Patterns**\n\nJust paste the code or describe the concept, and I'll give you a clear explanation with examples!`;
        }
        
        if (lowerMsg.includes('debug') || lowerMsg.includes('error') || lowerMsg.includes('fix')) {
            return `I can help debug your code! 🔍\n\nTo help me find the issue faster, please include:\n\n1. **The error message** you're seeing\n2. **The relevant code** causing the error\n3. **What you expected** vs **what's happening**\n\nCommon debugging steps I can walk you through:\n- Console.log at key points\n- Check variable types\n- Verify API responses\n- Look for typos\n- Check async timing issues\n\nShare your code and I'll help identify and fix the problem!`;
        }
        
        if (lowerMsg.includes('project idea') || lowerMsg.includes('build')) {
            return `Great question! Here are some project ideas based on skill level:\n\n### Beginner Projects 🌱\n- **To-Do List App** - Learn DOM manipulation & state management\n- **Weather Dashboard** - Practice API integration\n- **Unit Converter** - Build calculators with multiple modes\n\n### Intermediate Projects 🚀\n- **E-commerce Product Page** - Complex UI & interactions\n- **Task Manager with Categories** - CRUD operations & filtering\n- **Recipe Search App** - External APIs & data handling\n\n### Advanced Projects ⚡\n- **Real-time Chat Application** - WebSockets & databases\n- **Code Editor** - Syntax highlighting & auto-complete\n- **Portfolio CMS** - User authentication & admin panel\n\nWhich one interests you? I can guide you through building any of these!`;
        }
        
        // Default helpful response
        return `Thanks for your message! I'm currently running in **demo mode**, so my responses are simulated.\n\nIn production with real AI configuration, using **${this.currentProvider.toUpperCase()}**, I would be able to:\n\n✅ Write and explain complex code\n✅ Debug issues in your programs\n✅ Help design system architecture\n✅ Suggest best practices\n✅ Convert between programming languages\n\n### To enable full AI capabilities:\n\n1. Set up backend API server\n2. Configure API keys:\n   - \`OPENAI_API_KEY\` for ChatGPT\n   - \`GEMINI_API_KEY\` for Gemini (requires Google auth)\n   - \`ANTHROPIC_API_KEY\` for Claude (requires VIP)\n\nIs there something specific about coding I can help you understand?`;
    },
    
    // Get messages in API format
    getApiMessages() {
        return this.chatHistory.map(m => ({
            role: m.role,
            content: m.content
        }));
    },
    
    // Add message to chat
    addMessage(content, role, isError = false) {
        const container = document.getElementById('chat-messages');
        if (!container) return;
        
        // Store in history
        this.chatHistory.push({ role: role === 'user' ? 'user' : 'assistant', content });
        
        // Remove welcome message if present
        const welcomeMsg = container.querySelector('.welcome-message');
        if (welcomeMsg) welcomeMsg.remove();
        
        // Create message element
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${role}-message${isError ? ' error-message' : ''}`;
        
        const avatarIcon = role === 'user' ? 'fa-user' : 'fa-robot';
        
        messageDiv.innerHTML = `
            <div class="message-avatar">
                <i class="fas ${avatarIcon}"></i>
            </div>
            <div class="message-content">
                <div class="message-bubble">${this.formatMessage(content)}</div>
            </div>
        `;
        
        container.appendChild(messageDiv);
        
        // Scroll to bottom
        container.scrollTop = container.scrollHeight;
    },
    
    // Format message content (handle markdown-like syntax)
    formatMessage(content) {
        // Escape HTML first
        let formatted = content
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
        
        // Format code blocks
        formatted = formatted.replace(/```(\w*)\n([\s\S]*?)```/g, (match, lang, code) => {
            const copyBtn = `<button class="copy-btn" onclick="this.parentElement.querySelector('pre').select(); document.execCommand('copy'); this.textContent='Copied!';">
                <i class="fas fa-copy"></i> Copy
            </button>`;
            return `<div class="pre-container">${copyBtn}<pre><code class="language-${lang || 'text'}">${code.trim()}</code></pre></div>`;
        });
        
        // Format inline code
        formatted = formatted.replace(/`([^`]+)`/g, '<code>$1</code>');
        
        // Format bold
        formatted = formatted.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
        
        // Format italic
        formatted = formatted.replace(/\*([^*]+)\*/g, '<em>$1</em>');
        
        // Format line breaks
        formatted = formatted.replace(/\n/g, '<br>');
        
        return formatted;
    },
    
    // Hide welcome message
    hideWelcomeMessage() {
        const welcome = document.querySelector('#chat-messages .welcome-message');
        if (welcome) {
            welcome.style.display = 'none';
        }
    },
    
    // Show typing indicator
    showTypingIndicator() {
        const container = document.getElementById('chat-messages');
        if (!container) return;
        
        const typingDiv = document.createElement('div');
        typingDiv.className = 'message ai-message';
        typingDiv.id = 'typing-indicator';
        typingDiv.innerHTML = `
            <div class="message-avatar"><i class="fas fa-robot"></i></div>
            <div class="message-content">
                <div class="message-bubble">
                    <div class="typing-indicator">
                        <span></span><span></span><span></span>
                    </div>
                </div>
            </div>
        `;
        
        container.appendChild(typingDiv);
        container.scrollTop = container.scrollHeight;
    },
    
    // Remove typing indicator
    removeTypingIndicator() {
        document.getElementById('typing-indicator')?.remove();
    },
    
    // Clear conversation
    clearConversation() {
        this.chatHistory = [];
        
        const container = document.getElementById('chat-messages');
        if (container) {
            container.innerHTML = '';
            this.renderWelcomeMessage();
        }
        
        showToast('info', 'Cleared', 'Conversation has been cleared');
    },
    
    // Bind event listeners
    bindEvents() {
        // Provider selection
        document.querySelectorAll('.provider-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.selectProvider(btn.dataset.provider);
            });
        });
        
        // Send button
        document.getElementById('send-btn')?.addEventListener('click', () => {
            this.sendMessage();
        });
        
        // Input field
        const chatInput = document.getElementById('chat-input');
        if (chatInput) {
            // Enable/disable send button based on content
            chatInput.addEventListener('input', () => {
                document.getElementById('send-btn').disabled = !chatInput.value.trim();
            });
            
            // Handle Enter to send
            chatInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
            
            // Auto-resize textarea
            chatInput.addEventListener('input', function() {
                this.style.height = 'auto';
                this.style.height = Math.min(this.scrollHeight, 150) + 'px';
            });
        }
        
        // Quick action buttons
        document.querySelectorAll('.quick-action-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const prompt = btn.dataset.prompt;
                const input = document.getElementById('chat-input');
                if (input) {
                    input.value = prompt;
                    document.getElementById('send-btn').disabled = false;
                    input.focus();
                }
            });
        });
        
        // Clear conversation button
        document.getElementById('clear-chat-btn')?.addEventListener('click', () => {
            if (this.chatHistory.length > 0) {
                if (confirm('Clear all messages from this conversation?')) {
                    this.clearConversation();
                }
            }
        });
    }
};

// Expose globally
window.AIAssistantManager = AIAssistantManager;

document.addEventListener('DOMContentLoaded', () => {
    AIAssistantManager.init();
});